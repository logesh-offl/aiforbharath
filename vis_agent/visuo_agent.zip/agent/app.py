import asyncio
import base64
import json
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from bs4 import BeautifulSoup
from playwright.async_api import async_playwright

# Strands Agents SDK
from strands import Agent

# --------- Data models ---------
@dataclass
class CaptureResult:
    url: str
    html: str
    visible_text: str
    css_text: str
    full_page_png_b64: str
    viewport: Dict[str, Any]


# --------- Browser capture tools ---------
async def capture_page(url: str, *, width: int = 1440, height: int = 900, wait_ms: int = 1500) -> CaptureResult:
    """Open URL, take full page screenshot, extract HTML + CSS (inline + external), and some visible text."""

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(viewport={"width": width, "height": height})
        page = await context.new_page()

        await page.goto(url, wait_until="networkidle")
        await page.wait_for_timeout(wait_ms)

        # Full-page screenshot (equivalent of DevTools 'Capture full size screenshot')
        png_bytes = await page.screenshot(full_page=True, type="png")
        png_b64 = base64.b64encode(png_bytes).decode("utf-8")

        # HTML
        html = await page.content()

        # Extract visible text (rough) from HTML
        soup = BeautifulSoup(html, "lxml")
        for tag in soup(["script", "style", "noscript"]):
            tag.decompose()
        visible_text = " ".join(soup.get_text(" ").split())

        # Collect stylesheets + inline styles
        css_parts: List[str] = []

        # Inline <style>
        inline_styles = await page.eval_on_selector_all(
            "style",
            "els => els.map(e => e.textContent || '').filter(Boolean)"
        )
        css_parts.extend(inline_styles)

        # External stylesheets
        hrefs = await page.eval_on_selector_all(
            "link[rel=stylesheet]",
            "els => els.map(e => e.href).filter(Boolean)"
        )
        for href in hrefs:
            try:
                resp = await page.request.get(href)
                if resp.ok:
                    css_parts.append(await resp.text())
            except Exception:
                # ignore individual stylesheet failures
                pass

        css_text = "\n\n".join(css_parts)

        await context.close()
        await browser.close()

    return CaptureResult(
        url=url,
        html=html,
        visible_text=visible_text[:12000],
        css_text=css_text[:200000],
        full_page_png_b64=png_b64,
        viewport={"width": width, "height": height},
    )


# --------- LLM generation (Strands) ---------
SYSTEM_PROMPT = """You are a senior frontend engineer. You will be given:
- full-page screenshot (base64 PNG),
- HTML, extracted text, and CSS from a target landing page.
Your job: generate a runnable Flutter app that recreates the UI as closely as reasonable.

Requirements:
- Output a complete Flutter project skeleton with: pubspec.yaml, lib/main.dart, README.md.
- Use Material 3, dark theme, and google_fonts (Inter).
- Implement sections: hero, workflow cards, stats grid, CTA, articles, footer.
- Keep code in a single file: lib/main.dart.
- Include the screenshot as an asset at assets/reference.png.
- Provide commands for running locally (flutter pub get, flutter run).

Return JSON with keys: files (list of {path, content}).
"""


def build_agent() -> Agent:
    # Provider/model selection depends on your Strands configuration.
    # Set your provider via environment variables or Strands config.
    # The user requested Claude 4.5 Haiku.
    return Agent(
        system_prompt=SYSTEM_PROMPT,
        # If your Strands setup supports explicit model selection, set it here.
        # Example patterns vary by provider; see Strands docs.
        model="claude-haiku-4-5",
        tools=[],
    )


def write_project(out_dir: str, files: List[Dict[str, str]]) -> None:
    for f in files:
        path = os.path.join(out_dir, f["path"])
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as w:
            w.write(f["content"])


async def generate_flutter_from_url(url: str, out_dir: str = "./out_flutter") -> str:
    cap = await capture_page(url)

    agent = build_agent()

    user_payload = {
        "url": cap.url,
        "viewport": cap.viewport,
        "html": cap.html,
        "visible_text": cap.visible_text,
        "css": cap.css_text,
        "screenshot_png_base64": cap.full_page_png_b64,
    }

    result = agent(json.dumps(user_payload))

    # Strands typically returns an object with .message or directly a string depending on SDK.
    # Handle both.
    raw = getattr(result, "message", result)
    data = json.loads(raw)

    # Write files
    os.makedirs(out_dir, exist_ok=True)
    write_project(out_dir, data["files"])

    # Write screenshot asset
    assets_path = os.path.join(out_dir, "assets", "reference.png")
    os.makedirs(os.path.dirname(assets_path), exist_ok=True)
    with open(assets_path, "wb") as w:
        w.write(base64.b64decode(cap.full_page_png_b64))

    return out_dir


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Capture a web UI and generate a Flutter landing page project.")
    parser.add_argument("url", help="Target UI URL")
    parser.add_argument("--out", default="out_flutter", help="Output directory")
    args = parser.parse_args()

    asyncio.run(generate_flutter_from_url(args.url, args.out))
    print(f"Generated Flutter project at: {args.out}")


if __name__ == "__main__":
    main()
